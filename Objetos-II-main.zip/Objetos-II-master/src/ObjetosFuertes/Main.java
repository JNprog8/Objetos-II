package ObjetosFuertes;

public class Main {
    public static void main(String[] args) {
        Tiempo tiempo = new Tiempo();
        tiempo.formatoLargo();
        tiempo.formatoCorto();
    }
}
